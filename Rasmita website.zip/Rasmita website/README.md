# Star Child School — Bold five-page website

Pages: Home, About Us, Academics & Facilities, Gallery, Contact & Admissions.

Run: Extract ZIP, open the folder in VS Code and launch `index.html` with Live Server.

Before publishing:
- In `script.js`, set the real WhatsApp number and admissions email.
- Replace placeholder address, phone, email, office hours and principal message.
- Replace the general Bhiwadi map with the exact verified campus map pin.
- Replace illustrative stock images with school-approved photographs.
- Verify all curriculum, grade and facility details.

The enquiry form validates fields and opens the visitor's email app using `mailto:`; it is not a server-backed form. For reliable production enquiries, connect a secure backend or trusted form service. GSAP and Google Fonts load from CDNs.
